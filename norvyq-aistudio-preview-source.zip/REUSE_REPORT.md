# Source reuse and runtime boundaries

Source: `Bloomburgssalmuk/NORVYQ`, main commit
`1a915935609c9fc36df1f1fdc0de0e33d8fc6cff`.

| Original | Preview reuse | Changes |
|---|---|---|
| `app/styles/tokens.css` | `src/styles/tokens.css` | Verbatim; Dark/Light tokens remain shared. |
| `app/styles/primitives.css` | `src/styles/primitives.css` | Verbatim; local preview layout overrides are separate. |
| `app/design-tokens*.json` | `src/design-tokens*.json` | Verbatim provenance references. |
| `app/terminal/navigation.ts` | `src/terminal/navigation.ts` | Verbatim workspace definitions, deep links, validation and legacy aliases; local UiLanguage type shim. |
| `app/quant/performance-analytics.ts` | `src/quant/performance-analytics.ts` | Verbatim pure mathematics; only synthetic inputs are supplied. |
| `app/qx-ui.tsx` | `src/components/qx-ui.tsx` | Thirteen pure component exports extracted with their implementations; React import reduced. Panel, Button, Input, Select, Badge, Table, EmptyState, Skeleton, ScoreBars, Section, MetricRow, SegmentedControl and StatusDot. Some are retained for further frontend development. |
| `app/quant-intelligence-results.tsx` | `src/components/research-series.tsx` | Extracted Series renderer and number formatter; exported as ResearchSeries, fixture labels and local color styling. |
| `public/fonts/manrope-latin-v20.woff2` + OFL | `public/fonts/` | Verbatim; self-contained font loading. |

## Adapted / newly implemented

The shell follows the original navigation groups, neutral carbon palette,
financial typography, sidebar/topbar layout, tables, semantic colors and
Dark/Light/System conventions. It is a portable frontend port, not a byte-for-byte
copy of the full terminal. It does not preserve every production workflow.

`src/App.tsx` replaces Next/server route state and provider calls with local
query-string navigation, fixtures and explicit unavailable panels. The metric
presentation omits production global chart/drilldown bindings. The OHLC SVG chart
is a new dependency-free counterpart, not the production chart runtime. The
conceptual volatility grid is a local layout fixture, not a port of calibrated
3D option analytics. Portfolio and paper views are display fixtures with no
order creation. Research Lab uses the copied pure performance code for arithmetic
on a synthetic path; no model, strategy, engine or promotion is invoked.

News has placeholder editorial rows, not real articles or events. Macro and
research scores are clearly synthetic; missing values remain unavailable. Local
search indexes fixture instruments only. Only theme preference persists locally.

## Unavailable

- Next.js 16 server routes/actions, Vinext, Cloudflare workers/plugins/bindings,
  D1/R2, scheduled jobs, special Sites installation and production deployment.
- Authenticated accounts, real portfolio records, broker connections, orders,
  paper execution, scheduler, trading agents and execution authority.
- GS Quant, Qlib, Riskfolio, Python/FastAPI research engines, AI providers,
  retrieval, training, automated research, tournament governance and validation.
- Live news, earnings calendars/results, financial statements, SEC evidence,
  DCF/price targets, probability forecasts, macro archives and commodity pipelines.
- Observed options chains, Greeks/GEX, calibrated surfaces, futures, market
  microstructure, actual backtests, OOS/prospective performance and live data by
  default. An optional public JSON adapter enables only one read-only chart.

## Isolation

This folder has its own package manifest, lockfile, entry point, TypeScript
configuration, Vite configuration and scripts. No parent path imports, parent
packages, production data, production environment files or backend services are
required. No production files were changed. No root dependency installation,
remote write, merge, push or deployment was performed for this preview task.
