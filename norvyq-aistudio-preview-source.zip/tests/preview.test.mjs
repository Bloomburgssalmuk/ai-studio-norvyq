import {test} from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import {validateSnapshot,publicEndpoint,loadPublicSnapshot} from '../src/data/public-adapter.mjs';

const fixture=()=>({symbol:'QQQ',currency:'USD',source:'Unit test fixture',asOf:'2025-01-04T20:00:00Z',bars:[{date:'2025-01-02',open:100,high:102,low:99,close:101},{date:'2025-01-03',open:101,high:103,low:100,close:102}]});
test('public snapshot validates identity, prices, ordering and source dates',()=>{
  assert.equal(validateSnapshot(fixture(),'QQQ').mode,'READ_ONLY');
  for(const mutate of [v=>v.symbol='SPY',v=>v.source='',v=>v.bars[0].close=NaN,v=>v.bars[0].low=999,v=>v.bars.reverse(),v=>v.bars[0].date='2025-02-30',v=>v.asOf='2024-01-01']){
    const v=fixture();mutate(v);assert.throws(()=>validateSnapshot(v,'QQQ'));
  }
});
test('adapter refuses credentials, query secrets, local hosts and insecure URLs',()=>{
  assert.equal(publicEndpoint('https://example.com/market/qqq.json').protocol,'https:');
  for(const url of ['http://example.com','https://user:pass@example.com','https://example.com?key=secret','https://localhost/data','https://127.0.0.1','https://example.internal/data','https://[::1]/data','https://example.com#secret']) assert.throws(()=>publicEndpoint(url));
});
test('adapter makes only an unauthenticated GET and fails closed',async()=>{
  const result=await loadPublicSnapshot('https://example.com/qqq.json','QQQ',async(url,options)=>{
    assert.equal(url,'https://example.com/qqq.json');assert.equal(options.method,'GET');assert.equal(options.credentials,'omit');assert.equal(options.redirect,'error');assert.deepEqual(options.headers,{Accept:'application/json'});
    return {ok:true,json:async()=>fixture()};
  });assert.equal(result.mode,'READ_ONLY');
  await assert.rejects(loadPublicSnapshot('https://example.com/qqq.json','QQQ',async()=>({ok:false,status:403})),/403/);
  await assert.rejects(loadPublicSnapshot('https://example.com/qqq.json','QQQ',async()=>({ok:true,json:async()=>({})})),/Invalid/);
});
test('runtime dependencies are isolated and contain no production installer',()=>{
  const pkg=JSON.parse(fs.readFileSync(new URL('../package.json',import.meta.url),'utf8'));
  assert.deepEqual(Object.keys(pkg.dependencies).sort(),['react','react-dom']);
  assert.ok(!['preinstall','install','postinstall','prepare'].some(k=>k in pkg.scripts));
  const config=fs.readFileSync(new URL('../vite.config.ts',import.meta.url),'utf8');
  assert.ok(!/cloudflare|vinext|fastapi|wrangler/i.test(config));
});
