# Standalone frontend development

This repository is the isolated NORVYQ preview, not its production repository.
Keep React + TypeScript + Vite standalone. Do not add Vinext, Next.js server
requirements, Cloudflare bindings, Sites installation scripts, FastAPI, production
credentials, private account data or broker/order methods. Default to labeled
synthetic fixtures. Preserve explicit UNAVAILABLE states. Real public data belongs
behind optional read-only adapters and must display source and time. Never put
keys in VITE_PUBLIC_ variables. Run focused tests and one build for relevant changes.
