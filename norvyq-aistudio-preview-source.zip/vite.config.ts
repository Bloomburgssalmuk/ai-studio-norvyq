import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';

export default defineConfig({
  plugins: [react()],
  base: './',
  envDir: '.',
  envPrefix: 'VITE_PUBLIC_',
  // Do not discover the production repository's parent PostCSS/Tailwind config.
  css: { postcss: { plugins: [] } },
  // Hosted development previews use a proxy hostname. Serve this command only
  // in a development sandbox; distribute dist/ for static hosting.
  server: { host: '0.0.0.0', port: 3000, allowedHosts: true, fs: { strict: true } },
  preview: { host: '0.0.0.0', port: 3000 },
});
