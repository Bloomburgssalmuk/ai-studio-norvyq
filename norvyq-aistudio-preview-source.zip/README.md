# NORVYQ · AI Studio frontend preview

Standalone React 19 + TypeScript + Vite 8 development project. No Next.js,
Vinext, Cloudflare plugin, Python/FastAPI, D1/R2, Sites installer or production
environment is needed. Default data is deterministic and synthetic. Every
workspace is labeled DEMO; execution authority is always NONE.

## Run from this folder (or the new repository root)

Use Node **22.12+** (recommended) or Node **20.19+**. A current Node 24 release
also works. No parent repository dependencies are required.

```sh
npm ci
npm run dev
```

Open http://localhost:3000. Vite listens on 0.0.0.0 for hosted development
previews. A busy port may cause Vite to choose the next port; read its output.

```sh
npm test
npm run build
npm run preview
```

`build` checks TypeScript and emits static files to `dist/`. Deploy **dist/**
to any static host. It needs no Node server, bindings, database or secrets.
Query-string navigation works without a server rewrite. All assets, including
the licensed Manrope font, are local. Dev hostname checks allow hosted preview
proxies; use the built static output for public hosting.

## Put this package in a NEW GitHub repository

1. Extract the **source ZIP** into an empty directory. Its top level must have
   `package.json`, `package-lock.json`, `index.html`, `vite.config.ts`, and `src/`.
   Do not put those files inside an extra `aistudio-preview/` folder in the new repo.
2. Create a **new private GitHub repository** for this standalone frontend.
   Preserve your existing NORVYQ source access restrictions. Do not reuse the
   production repository or its remote URL. This task does not create or push it.
3. From that new directory, run the following yourself, replacing the placeholder:

   ```sh
   git init -b main
   git add .
   git commit -m "Add isolated NORVYQ frontend preview"
   git remote add origin https://github.com/YOUR-ACCOUNT/NEW-PREVIEW-REPOSITORY.git
   git push -u origin main
   ```

4. In Google AI Studio **Build**, use **Add files (+) → Import from GitHub**
   and choose the new repository. Its root is already the standalone app root.
   Development command: `npm run dev`; build command: `npm run build`;
   output directory: `dist`; development port: `3000`.
5. Keep development in that separate repository. No code or environment from
   this preview needs to be copied into the production project.

The package has been checked locally; actual import into your Google account
is not performed by this task. GitHub connection availability is controlled by
AI Studio and your account. See [Google's Build import instructions](https://aistudio.google.com/docs/aistudio-build-mode)
and [Vite's Node requirements](https://vite.dev/guide/).

## Working features

- Incumbent workspace navigation and validated query-string context; browser Back.
- Search the six fixture instruments (Ctrl/Cmd K), select a symbol, change chart
  range, and inspect the OHLC chart with pointer or arrow keys.
- Dark / Light / System appearance with the same tokens and components.
- Responsive sidebar, keyboard navigation, local fixture export, watchlist,
  synthetic research scores, conceptual IV grid, macro scores and news placeholders.
- Read-only synthetic portfolio display and original performance mathematics on
  a separate synthetic QQQ path. The fee slider is an arithmetic illustration,
  **not a trading simulator or backtest**. No turnover, slippage, fills, observed
  risk-free rate, real calendar or validation evidence is invented.

Production analytics controls with no standalone implementation are deliberately
unavailable rather than simulated as functioning integrations. The UI is English;
the original Korean navigation definitions are preserved as source only.

## Optional public data adapter

The app makes **no market/API/provider requests by default**. To test an actual
public data integration, copy `.env.example` to `.env.local` **inside this new
project**, set `VITE_PUBLIC_MARKET_DATA_URL` to a public HTTPS JSON URL, and restart
Vite. Never copy a production `.env` or add credentials. Browser-visible variables
are not secrets. URL userinfo, query parameters, fragments, local/IP hosts and
redirects are rejected. Endpoint owners must allow browser CORS requests.

Go to Operations and click **Connect public snapshot**. It performs one GET,
omits credentials and referrer, and validates the selected symbol, USD prices,
OHLC consistency, source metadata and ordered dates. No cookies, tokens, auth
headers, write methods, proxies or trade methods exist in the adapter. Example
response for selected QQQ (replace with genuine public observations and source):

```json
{
  "symbol": "QQQ",
  "currency": "USD",
  "source": "YOUR PUBLIC DATA SOURCE",
  "asOf": "2025-01-03T21:00:00Z",
  "bars": [
    { "date": "2025-01-02", "open": 100, "high": 102, "low": 99, "close": 101 },
    { "date": "2025-01-03", "open": 101, "high": 103, "low": 100, "close": 102 }
  ]
}
```

This JSON is a **schema example with synthetic numbers**, not actual QQQ prices.
Only the market chart uses the returned snapshot and changes to **READ_ONLY**;
its source and timestamp remain visible. Other panels stay DEMO. An adapter error
reports UNAVAILABLE and explicitly retains the labeled demo chart. Source dates
are displayed, not certified as current. Changing instruments does not issue a
request; connect an endpoint supplying that symbol explicitly.

## Provenance & restrictions

See `REUSE_REPORT.md` for copied/adapted/unavailable components and
`SOURCE_MANIFEST.json` for upstream SHA and SHA-256 of verbatim copies. Original
NORVYQ source is not modified. This package does not grant a new license to
NORVYQ code; retain its owner's access and distribution rights. The included
Manrope font retains `public/fonts/Manrope-OFL.txt`.
