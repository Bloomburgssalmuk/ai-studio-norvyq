import type { UiLanguage } from "../ui-language";

export type View =
  | "overview"
  | "markets"
  | "research"
  | "earnings"
  | "news"
  | "derivatives"
  | "portfolio"
  | "paper"
  | "macro"
  | "commodity"
  | "intelligence"
  | "lab"
  | "system";

export const TERMINAL_VIEWS: View[] = [
  "overview",
  "markets",
  "research",
  "earnings",
  "news",
  "derivatives",
  "portfolio",
  "paper",
  "macro",
  "commodity",
  "intelligence",
  "lab",
  "system",
];

export type TerminalDeepLink = {
  view: View;
  symbol?: string;
  tab?: string;
  objectId?: string;
  range?: string;
  model?: string;
  scenario?: string;
  expiry?: string;
  portfolio?: string;
};

const safeSymbol = (value: string | null) =>
  value && /^[A-Z0-9.^=-]{1,15}$/.test(value.toUpperCase())
    ? value.toUpperCase()
    : undefined;

export function parseTerminalDeepLink(search: string): TerminalDeepLink {
  const params = new URLSearchParams(search);
  const candidate = params.get("view");
  let view = TERMINAL_VIEWS.includes(candidate as View)
    ? (candidate as View)
    : "overview";
  const symbol = safeSymbol(params.get("symbol"));
  let tab = params.get("tab")?.slice(0, 30) || undefined;
  // Historical URLs remain valid while the modules live inside News and Lab.
  if (view === "earnings") { view = "news"; tab = `earnings-${tab || "calendar"}`; }
  if (view === "commodity") { view = "lab"; tab = "commodity"; }
  const objectId = params
    .get("object")
    ?.match(/^[a-z_]+:[A-Za-z0-9.^=_-]{1,80}$/)?.[0];

  const range = params.get("range")?.match(/^(?:1D|5D|1M|3M|6M|1Y|2Y|5Y|MAX)$/)?.[0];
  const model = params.get("model")?.match(/^[A-Za-z0-9_.:-]{1,80}$/)?.[0];
  const scenario = params.get("scenario")?.match(/^[A-Za-z0-9_.:-]{1,80}$/)?.[0];
  const expiry = params.get("expiry")?.match(/^\d{4}-\d{2}-\d{2}$/)?.[0];
  const portfolio = params.get("portfolio")?.match(/^portfolio:[A-Za-z0-9.^=_-]{1,80}$/)?.[0];
  return { view, symbol, tab, objectId, ...(range ? {range} : {}), ...(model ? {model} : {}), ...(scenario ? {scenario} : {}), ...(expiry ? {expiry} : {}), ...(portfolio ? {portfolio} : {}) };
}

export function terminalDeepLink(state: TerminalDeepLink) {
  if (state.view === "earnings") state = { ...state, view: "news", tab: `earnings-${state.tab || "calendar"}` };
  if (state.view === "commodity") state = { ...state, view: "lab", tab: "commodity" };
  const params = new URLSearchParams();
  params.set("view", state.view);
  if (state.symbol) params.set("symbol", state.symbol);
  if (state.tab) params.set("tab", state.tab);
  if (state.objectId) params.set("object", state.objectId);
  if (state.range) params.set("range", state.range);
  if (state.model) params.set("model", state.model);
  if (state.scenario) params.set("scenario", state.scenario);
  if (state.expiry) params.set("expiry", state.expiry);
  if (state.portfolio) params.set("portfolio", state.portfolio);
  const query = params.toString();
  return query ? `/?${query}` : "/";
}

export type NavGroup = "decision" | "analysis" | "research";

export const PRIMARY_WORKSPACES: readonly View[] = ["overview", "markets", "research", "news", "portfolio", "paper"];
export const isWorkspaceVisible = ({ id }: { id: View }) => id !== "earnings" && id !== "commodity";

export type NavItem = {
  id: View;
  label: string;
  sub: string;
  glyph: string;
  group: NavGroup;
  mobile?: string;
};

export const NAV_ITEMS_KO: NavItem[] = [
  {id:'news',label:'Live News',sub:'공식 피드 · 실적',glyph:'NWS',group:'decision',mobile:'뉴스'},
  { id: "overview", label: "Overview", sub: "오늘의 시장 상태", glyph: "PLS", group: "decision", mobile: "Overview" },
  { id: "markets", label: "Markets", sub: "QQQ 시장 상태", glyph: "MKT", group: "decision", mobile: "시장" },
  { id: "macro", label: "Macro", sub: "레짐 · 유동성 · 교차자산", glyph: "FLX", group: "decision", mobile: "매크로" },
  { id: "commodity", label: "Commodity", sub: "에너지 · 금속 · 커브", glyph: "CMD", group: "decision", mobile: "원자재" },
  { id: "research", label: "Research", sub: "기업 · 가치 · 위험", glyph: "EQ", group: "decision", mobile: "리서치" },
  {id:"earnings",label:"Earnings",sub:"실적 · 일정 · 기대 · 결과",glyph:"ERN",group:"decision",mobile:"실적"},
  { id: "derivatives", label: "Derivatives", sub: "옵션 · 3D · GEX", glyph: "IV", group: "analysis", mobile: "파생" },
  { id: "portfolio", label: "Portfolio", sub: "포지션 · 위험 · 헤지", glyph: "PF", group: "analysis", mobile: "포폴" },
  { id: "lab", label: "Research Lab", sub: "가설 · 검증 · 원자재", glyph: "VAL", group: "analysis", mobile: "연구실" },
  { id: "paper", label: "Paper Trading", sub: "에이전트 · 주문 · NAV", glyph: "PTR", group: "analysis", mobile: "페이퍼" },
  { id: "intelligence", label: "Intelligence", sub: "이슈 · 논제 · 연구 근거", glyph: "RES", group: "research" },
  { id: "system", label: "Operations", sub: "데이터 · 모델 · 감사", glyph: "OPS", group: "research" },
];

// Compatibility names retained for deep links and historical audit records; the
// visible navigation uses the consolidated Research Lab and Operations destinations.
export const LEGACY_NAV_ALIASES = [
  { label: "Research Lab", view: "lab" },
  { label: "Backtest", view: "lab" },
  { label: "System", view: "system" },
] as const;

export const NAV_ITEMS_EN: NavItem[] = [
  {id:'news',label:'Live News',sub:'Official feeds · Earnings',glyph:'NWS',group:'decision',mobile:'News'},
  { id: "overview", label: "Overview", sub: "Today's market state", glyph: "PLS", group: "decision", mobile: "Overview" },
  { id: "markets", label: "Markets", sub: "QQQ market state", glyph: "MKT", group: "decision", mobile: "Markets" },
  { id: "macro", label: "Macro", sub: "Regime · Liquidity · Cross asset", glyph: "FLX", group: "decision", mobile: "Macro" },
  { id: "commodity", label: "Commodity", sub: "Energy · Metals · Curves", glyph: "CMD", group: "decision", mobile: "Commodity" },
  { id: "research", label: "Research", sub: "Company · Value · Risk", glyph: "EQ", group: "decision", mobile: "Research" },
  {id:"earnings",label:"Earnings",sub:"Calendar · Results · Event research",glyph:"ERN",group:"decision",mobile:"Earnings"},
  { id: "derivatives", label: "Derivatives", sub: "Options · 3D · GEX", glyph: "IV", group: "analysis", mobile: "Deriv." },
  { id: "portfolio", label: "Portfolio", sub: "Positions · Risk · Hedge", glyph: "PF", group: "analysis", mobile: "Portfolio" },
  { id: "lab", label: "Research Lab", sub: "Hypotheses · Validation · Commodities", glyph: "VAL", group: "analysis", mobile: "Lab" },
  { id: "paper", label: "Paper Trading", sub: "Agents · Orders · NAV", glyph: "PTR", group: "analysis", mobile: "Paper" },
  { id: "intelligence", label: "Intelligence", sub: "Issues · Theses · Research evidence", glyph: "RES", group: "research" },
  { id: "system", label: "Operations", sub: "Data · Models · Audit", glyph: "OPS", group: "research" },
];

export const NAV_GROUP_LABELS: Record<UiLanguage, Record<NavGroup, string>> = {
  ko: { decision: "판단", analysis: "분석 · 검증", research: "연구 · 운영" },
  en: { decision: "DECISION", analysis: "ANALYTICS · VALIDATION", research: "RESEARCH · OPS" },
};

export const VIEW_PURPOSE: Record<UiLanguage, Record<View, string>> = {
  ko: {
    news:'공식 RSS 메타데이터를 개인용으로 모아 읽습니다. 발행 시각과 감지 시각을 구분하며 실시간 전달을 보장하지 않습니다.',
    earnings: "발표 일정과 검증된 실적, 옵션 및 이벤트 연구를 연결합니다.",
    overview: "현재 시장 상태, 핵심 시세와 관심자산을 요약합니다.",
    markets: "QQQ 전용 시장 상태·가격 구조·XENUS·EXO 분석을 실행합니다.",
    portfolio: "평단·규모 기반 포지션과 기관형 위험 예산을 관리합니다.",
    paper: "클라우드에서 실행되는 독립 에이전트의 주문·체결·NAV를 감사합니다.",
    research: "종목별 기업·가치·기술·경매·예측 리서치를 통합합니다.",
    derivatives: "옵션 체인·3D 표면·GEX·미시구조·선물을 한곳에서 탐색합니다.",
    macro: "유동성·금리·달러·크레딧과 글로벌 레짐을 확인합니다.",
    commodity: "에너지·금속·선물 커브·물리 수급을 독립적으로 분석합니다.",
    intelligence: "증거 기반 연구 이슈, 변화, 논제와 Hunter 예외를 추적합니다.",
    lab: "가설·팩터·연구위원회·실험·출처를 탐색하고 기존 백테스트와 Paper/Champion 검증 근거를 연결합니다.",
    system: "데이터 공급, 모델 검증과 운영 무결성을 감사합니다.",
  },
  en: {
    news:'Read official RSS metadata privately, with separate publication and detection times and no real-time delivery guarantee.',
    earnings: "Connect earnings schedules, reported results, options and event research.",
    overview: "Summarize today's market decision, core tape and watched assets.",
    markets: "Run the dedicated QQQ market-state, price-structure, XENUS and EXO stack.",
    portfolio: "Manage cost-basis positions and institutional risk budgets.",
    paper: "Audit cloud-run paper agents, orders, fills and NAV.",
    research: "Unify company, valuation, technical, auction and forecast research by symbol.",
    derivatives: "Explore options, 3D surfaces, GEX, microstructure and futures in one workspace.",
    macro: "Review liquidity, rates, USD, credit and the global regime.",
    commodity: "Analyze energy, metals, futures curves and physical-supply evidence independently.",
    intelligence: "Track evidence-backed issues, changes, theses and Hunter exceptions.",
    lab: "Inspect hypotheses, factors, research council, experiments and provenance alongside backtest and paper/champion validation evidence.",
    system: "Audit data delivery, model validation and operational integrity.",
  },
};
