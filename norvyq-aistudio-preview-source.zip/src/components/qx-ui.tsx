import { useId, type ReactNode, type ComponentProps } from "react";

export function QXPanel({ className = "", ...props }: ComponentProps<"section">) {
  return <section className={`panel ${className}`} {...props} />;
}

export function QXButton({ className = "", variant = "default", type, ...props }: ComponentProps<"button"> & { variant?: "default" | "primary" | "danger" }) {
  return <button type={type} className={`qx-button ${className}`} data-variant={variant} {...props} />;
}

export function QXInput({ className = "", ...props }: ComponentProps<"input">) { return <input className={`qx-input ${className}`} {...props} />; }

export function QXSelect({ className = "", ...props }: ComponentProps<"select">) { return <select className={`qx-input ${className}`} {...props} />; }

export function QXBadge({ className = "", ...props }: ComponentProps<"span">) { return <span className={`qx-badge ${className}`} {...props} />; }

export function QXTable({ className = "", ...props }: ComponentProps<"table">) { return <div className="qx-table-scroll" role="region" aria-label={props["aria-label"]??"Financial data table · scroll horizontally"} tabIndex={0}><table className={`qx-table ${className}`} {...props} /></div>; }

export function QXEmptyState({ children, className = "" }: { children: ReactNode; className?: string }) { return <div className={`qx-state ${className}`} role="status">{children}</div>; }

export function QXSkeleton({ label, className = "" }: { label: string; className?: string }) { return <div className={`qx-skeleton ${className}`} role="status" aria-label={label} aria-busy="true" />; }

/** Zero is an observed value. Missing/nonfinite values never acquire a score. */

export function QXScoreBars({ items, digits = 0, suffix = "" }: { items: [string, number | null, string?][]; digits?: number; suffix?: string }) {
  const id = useId();
  return <div className="qx-score-bars">{items.map(([label, value, detail], index) => {
    const missing = value == null || !Number.isFinite(value);
    const width = missing ? 0 : Math.max(0, Math.min(100, value));
    const display = missing ? "N/A" : `${value.toFixed(digits)}${suffix}`;
    return <div key={label} className="qx-score-row" data-missing={missing || undefined} data-zero={!missing && value === 0 || undefined}>
      <span id={`${id}-${index}`} className="qx-score-label">{label}{detail && <small>{detail}</small>}</span>
      <div className="qx-score-track" role={missing ? undefined : "meter"} aria-labelledby={`${id}-${index}`} aria-valuemin={missing ? undefined : 0} aria-valuemax={missing ? undefined : 100} aria-valuenow={missing ? undefined : width} aria-valuetext={missing ? undefined : `${display}${detail ? ` · ${detail}` : ""}`}><span className="qx-score-fill" style={{ width: `${width}%` }} /></div>
      <strong className="qx-score-value">{display}</strong>
    </div>;
  })}</div>;
}

export function QXSection({ title, description, action, children, className = "" }: { title: string; description?: string; action?: ReactNode; children: ReactNode; className?: string }) {
  return <section className={`qx-section ${className}`}><header><div><h2>{title}</h2>{description && <p>{description}</p>}</div>{action}</header>{children}</section>;
}

export function QXMetricRow({ children, className = "" }: { children: ReactNode; className?: string }) {
  return <div className={`qx-metric-row ${className}`}>{children}</div>;
}

export function QXSegmentedControl<T extends string>({ value, items, onChange, label }: { value: T; items: Array<{ value: T; label: string }>; onChange: (value: T) => void; label: string }) {
  const activeIndex = Math.max(0, items.findIndex((item) => item.value === value));
  return <div className="qx-segmented" role="tablist" aria-label={label} style={{ gridTemplateColumns: `repeat(${items.length}, minmax(max-content, 1fr))` }}><i aria-hidden="true" style={{ width: `${100 / items.length}%`, transform: `translateX(${activeIndex * 100}%)` }} />{items.map((item, index) => <button type="button" key={item.value} role="tab" tabIndex={index === activeIndex ? 0 : -1} aria-selected={value === item.value} className={value === item.value ? "active" : ""} onClick={() => onChange(item.value)} onKeyDown={event => {
    const next = event.key === "ArrowRight" ? (index + 1) % items.length : event.key === "ArrowLeft" ? (index - 1 + items.length) % items.length : event.key === "Home" ? 0 : event.key === "End" ? items.length - 1 : null;
    if (next === null) return;
    event.preventDefault();
    onChange(items[next].value);
    event.currentTarget.parentElement?.querySelectorAll<HTMLButtonElement>('[role="tab"]')[next]?.focus();
  }}>{item.label}</button>)}</div>;
}

export function QXStatusDot({ label, detail, state = "neutral", onClick }: { label: string; detail?: string; state?: "live" | "warning" | "neutral"; onClick?: () => void }) {
  const content = <><i className={state} /><span>{label}{detail && <small>{detail}</small>}</span></>;
  return onClick ? <button className="qx-status-dot" onClick={onClick}>{content}</button> : <div className="qx-status-dot">{content}</div>;
}
