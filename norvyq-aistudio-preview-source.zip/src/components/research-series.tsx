const n = (value: unknown, digits = 6) => typeof value === "number" && Number.isFinite(value) ? value.toFixed(digits) : "UNAVAILABLE";
function Series({ series, label }: { series: number[][]; label: string }) {
  const all = series.flat();
  if (!all.length || all.some(v => !Number.isFinite(v))) return null;
  const min = Math.min(...all), max = Math.max(...all), spread = Math.max(max-min, 1e-12);
  return <figure><svg viewBox="0 0 640 180" role="img" aria-label={label}><title>{label}</title>{series.map((line, index) => <polyline key={index} fill="none" stroke={index === 0 ? "var(--qx-accent)" : "var(--qx-secondary)"} strokeWidth="2" strokeDasharray={index > 0 ? "5 4" : undefined} points={line.map((v, i) => `${10+i/Math.max(1,line.length-1)*620},${160-(v-min)/spread*140}`).join(" ")} />)}</svg><figcaption className="qx-note">{label} · min {n(min)} · max {n(max)} · {all.length} values</figcaption></figure>;
}
export { Series as ResearchSeries };
