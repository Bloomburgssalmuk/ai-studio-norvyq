import { useState } from 'react';
import type { Snapshot } from '../data/fixtures';

/** Portable SVG counterpart to the server-fed production market chart. */
export function PriceChart({snapshot,range}:{snapshot:Snapshot;range:string}) {
  const [cursor,setCursor]=useState<number|null>(null);
  const bars=snapshot.bars.slice(range==='1M'?-22:range==='3M'?-66:-90);
  const min=Math.min(...bars.map(b=>b.low)),max=Math.max(...bars.map(b=>b.high)),spread=max-min||1;
  const x=(i:number)=>54+i/Math.max(1,bars.length-1)*822;
  const y=(v:number)=>216-(v-min)/spread*190;
  const active=bars[Math.min(cursor??bars.length-1,bars.length-1)];
  return <div className="price-chart">
    <div className="chart-readout" aria-live="polite"><span>{snapshot.mode} · {active.date}</span><span>O {active.open.toFixed(2)}　H {active.high.toFixed(2)}　L {active.low.toFixed(2)}　C <b>{active.close.toFixed(2)}</b></span></div>
    <svg viewBox="0 0 900 262" role="img" aria-label={`${snapshot.symbol} ${snapshot.mode} OHLC chart; ${bars.length} fixture or supplied sessions`} tabIndex={0}
      onPointerMove={e=>{const r=e.currentTarget.getBoundingClientRect();setCursor(Math.max(0,Math.min(bars.length-1,Math.round(((e.clientX-r.left)/r.width*900-54)/822*(bars.length-1)))));}}
      onPointerLeave={()=>setCursor(null)} onKeyDown={e=>{if(e.key==='ArrowLeft'||e.key==='ArrowRight'){e.preventDefault();setCursor(Math.max(0,Math.min(bars.length-1,(cursor??bars.length-1)+(e.key==='ArrowLeft'?-1:1))));}}}>
      <title>{snapshot.symbol} · {snapshot.mode} price in USD. Arrow keys inspect sessions.</title>
      {[0,1,2,3].map(i=><g key={i}><line x1="54" x2="880" y1={26+i*63} y2={26+i*63} className="grid-line"/><text x="2" y={30+i*63}>{(max-i/3*spread).toFixed(0)}</text></g>)}
      {bars.map((b,i)=><g key={b.date} className={b.close>=b.open?'candle up':'candle down'}><line x1={x(i)} x2={x(i)} y1={y(b.high)} y2={y(b.low)}/><rect x={x(i)-2.3} y={y(Math.max(b.open,b.close))} width="4.6" height={Math.max(1,Math.abs(y(b.close)-y(b.open)))}/></g>)}
      {cursor!==null&&<line x1={x(Math.min(cursor,bars.length-1))} x2={x(Math.min(cursor,bars.length-1))} y1="20" y2="220" className="crosshair"/>}
      {[0,Math.floor(bars.length/2),bars.length-1].map(i=><text key={i} x={x(i)} y="249" textAnchor={i===0?'start':i===bars.length-1?'end':'middle'}>{bars[i].date}</text>)}
    </svg>
    <p className="qx-note">USD · {snapshot.source} · As of {snapshot.asOf}. {snapshot.mode==='DEMO'?'Holidays and market microstructure are not modeled.':'External public snapshot; freshness is not guaranteed.'}</p>
  </div>;
}
