import { useEffect, useRef, useState } from 'react';
import { NAV_ITEMS_EN, NAV_GROUP_LABELS, isWorkspaceVisible, parseTerminalDeepLink, terminalDeepLink, type View } from './terminal/navigation';
import { QXPanel, QXButton, QXInput, QXSelect, QXBadge, QXTable, QXScoreBars, QXSegmentedControl, QXMetricRow } from './components/qx-ui';
import { ResearchSeries } from './components/research-series';
import { PriceChart } from './components/price-chart';
import { demoSnapshot, securities, positions, fixtureReturns, FIXTURE_NOTICE, type Snapshot } from './data/fixtures';
import { loadPublicSnapshot } from './data/public-adapter.mjs';
import { summarizeDaily, type AnalyticsContext } from './quant/performance-analytics';

const nav=NAV_ITEMS_EN.filter(isWorkspaceVisible);
const context:AnalyticsContext={scope:'SYNTHETIC_PREVIEW',returnBasis:'Fixture close-to-close',costs:'Gross; execution and slippage not modeled',cashFlows:'NONE',benchmark:'UNAVAILABLE',riskFree:{annual:null,source:'UNAVAILABLE',kind:'ASSUMED'},periodsPerYear:252};
const money=(v:number)=>v.toLocaleString('en-US',{style:'currency',currency:'USD',maximumFractionDigits:2});
const pct=(v:number|null)=>v===null?'UNAVAILABLE':`${v>=0?'+':''}${(v*100).toFixed(2)}%`;
const unavailable=[
  ['Production data','D1/R2 archives, credentials, portfolio records and authenticated APIs are disconnected.'],
  ['Research engines','GS Quant, Qlib, Riskfolio, Python workers, SEC ingestion, DCF and model inference are unavailable.'],
  ['Trading & automation','No brokers, order routes, paper scheduler, executions, account mutations or autonomous agents.'],
  ['Live services','No live quotes, option chains, news feeds, event calendars or AI provider calls by default.'],
];

function Metric({label,value,detail,tone='neutral'}:{label:string;value:string;detail:string;tone?:string}) {
  return <div className="qx-metric"><span>{label}</span><strong className={`qx-tone-${tone}`}>{value}</strong><small>{detail}</small></div>;
}
function Heading({title,detail,children}:{title:string;detail:string;children?:React.ReactNode}) {
  return <header className="panel-heading"><div><h2>{title}</h2><p>{detail}</p></div>{children??<QXBadge>DEMO</QXBadge>}</header>;
}
function ScopeNote(){return <p className="scope-note">{FIXTURE_NOTICE} Execution authority: <b>NONE</b>.</p>;}

export default function App(){
  const [location,setLocation]=useState(()=>parseTerminalDeepLink(window.location.search));
  const view=location.view;
  const symbol=securities.some(s=>s.symbol===location.symbol)?location.symbol!:'QQQ';
  const range=['1M','3M','6M'].includes(location.range??'')?location.range!:'3M';
  const [theme,setTheme]=useState(()=>{try{return localStorage.getItem('norvyq.preview.theme.v1')??'system';}catch{return 'system';}});
  const [menu,setMenu]=useState(false);
  const [mobile,setMobile]=useState(()=>window.matchMedia('(max-width: 760px)').matches);
  const [query,setQuery]=useState('');
  const [external,setExternal]=useState<Snapshot|null>(null);
  const [adapterState,setAdapterState]=useState('');
  const [connecting,setConnecting]=useState(false);
  const [fee,setFee]=useState(0);
  const [newsTab,setNewsTab]=useState<'briefs'|'earnings'>('briefs');
  const search=useRef<HTMLInputElement>(null),menuButton=useRef<HTMLButtonElement>(null),firstNav=useRef<HTMLButtonElement>(null);
  const publicUrl=import.meta.env.VITE_PUBLIC_MARKET_DATA_URL as string|undefined;
  const current=nav.find(n=>n.id===view)??nav.find(n=>n.id==='overview')!;
  const snapshot=external?.symbol===symbol?external:demoSnapshot(symbol);
  const last=snapshot.bars.at(-1)!,prior=snapshot.bars.at(-2)!;
  const summary=summarizeDaily(fixtureReturns.map(r=>({...r,value:r.value-fee/10000})),{...context,costs:fee?`Illustrative ${fee} bps deducted every session; not an execution simulation`:context.costs});
  const filtered=securities.filter(s=>`${s.symbol} ${s.name}`.toLowerCase().includes(query.toLowerCase()));
  const navigate=(next:View,nextSymbol=symbol)=>{
    const state={...location,view:next,symbol:nextSymbol};
    window.history.pushState({},'',terminalDeepLink(state));setLocation(parseTerminalDeepLink(window.location.search));setMenu(false);setQuery('');
  };
  const changeRange=(next:string)=>{const state={...location,range:next};window.history.pushState({},'',terminalDeepLink(state));setLocation(state);};
  useEffect(()=>{const pop=()=>setLocation(parseTerminalDeepLink(window.location.search));window.addEventListener('popstate',pop);return()=>window.removeEventListener('popstate',pop);},[]);
  useEffect(()=>{
    const media=window.matchMedia('(prefers-color-scheme: dark)');
    const apply=()=>{document.documentElement.dataset.theme=theme==='system'?(media.matches?'dark':'light'):theme;};
    apply();try{localStorage.setItem('norvyq.preview.theme.v1',theme);}catch{/* Persistence is optional. */}
    media.addEventListener('change',apply);return()=>media.removeEventListener('change',apply);
  },[theme]);
  useEffect(()=>{
    const keys=(e:KeyboardEvent)=>{
      if((e.ctrlKey||e.metaKey)&&e.key.toLowerCase()==='k'){e.preventDefault();search.current?.focus();}
      if(e.key==='Escape'){setQuery('');setMenu(false);if(menu)menuButton.current?.focus();}
    };window.addEventListener('keydown',keys);return()=>window.removeEventListener('keydown',keys);
  },[menu]);
  useEffect(()=>{if(menu)firstNav.current?.focus();},[menu]);
  useEffect(()=>{const media=window.matchMedia('(max-width: 760px)');const resize=()=>{setMobile(media.matches);setMenu(false);};media.addEventListener('change',resize);return()=>media.removeEventListener('change',resize);},[]);
  const connect=async()=>{
    if(!publicUrl){setAdapterState('No public endpoint configured. Demo mode remains active.');return;}
    setConnecting(true);setExternal(null);setAdapterState('');
    try{const result=await loadPublicSnapshot(publicUrl,symbol);setExternal(result as Snapshot);setAdapterState(`Connected read-only snapshot for ${symbol}. Other panels remain DEMO.`);}
    catch{setAdapterState('UNAVAILABLE · Public adapter failed or returned invalid data. Demo chart is explicitly shown; no live data was substituted.');}
    finally{setConnecting(false);}
  };
  const exportFixture=()=>{
    const blob=new Blob([JSON.stringify({notice:FIXTURE_NOTICE,executionAuthority:'NONE',snapshot:demoSnapshot(symbol)},null,2)],{type:'application/json'});
    const url=URL.createObjectURL(blob),a=document.createElement('a');a.href=url;a.download=`norvyq-DEMO-${symbol}.json`;a.click();setTimeout(()=>URL.revokeObjectURL(url),1000);
  };
  const watchlist=<QXTable aria-label="Synthetic demo watchlist"><thead><tr><th>Instrument</th><th>Fixture close</th><th>Session change</th><th>Source</th><th>Open</th></tr></thead><tbody>{filtered.map(s=>{const b=demoSnapshot(s.symbol).bars,c=b.at(-1)!.close,change=c/b.at(-2)!.close-1;return <tr key={s.symbol}><td><b>{s.symbol}</b><small className="cell-sub">{s.name}</small></td><td>{money(c)}</td><td className={change>=0?'up':'down'}>{pct(change)}</td><td><QXBadge>DEMO</QXBadge></td><td><QXButton onClick={()=>navigate('research',s.symbol)} aria-label={`Research ${s.symbol}`}>Research ↗</QXButton></td></tr>;})}</tbody></QXTable>;
  const chartPanel=<QXPanel><Heading title={`${symbol} · Market structure`} detail={snapshot.mode==='DEMO'?'Synthetic price history · fixture session, not today':`Public snapshot · ${snapshot.asOf}`}><QXBadge>{snapshot.mode}</QXBadge></Heading>
    <div className="chart-toolbar"><div className="quote"><strong>{money(last.close)}</strong><span className={last.close>=prior.close?'up':'down'}>{pct(last.close/prior.close-1)} <small>session</small></span></div><QXSegmentedControl label="Chart range" value={range} onChange={changeRange} items={['1M','3M','6M'].map(value=>({value,label:value==='6M'?'All 90':value}))}/></div>
    <PriceChart key={symbol} snapshot={snapshot} range={range}/></QXPanel>;
  const dataPanel=<QXPanel><Heading title="Preview boundaries" detail="Local frontend · no production runtime"/><div className="boundary-list"><div><i className="status-dot"/><span>UI & local calculations</span><b>AVAILABLE</b></div><div><i className="status-dot demo"/><span>Fixture data</span><b>DEMO</b></div><div><i className="status-dot off"/><span>Production services</span><b>OFFLINE</b></div><div><i className="status-dot off"/><span>Execution authority</span><b>NONE</b></div></div><QXButton className="full" onClick={()=>navigate('system')}>Inspect capabilities ↗</QXButton></QXPanel>;
  const analytics=<QXPanel><Heading title="Fixture path analytics" detail="Original NORVYQ calculations · synthetic inputs"/><QXMetricRow><Metric label="Total fixture return" value={pct(summary.metrics.totalReturn.value)} detail={`${summary.observations} artificial sessions`}/><Metric label="Maximum drawdown" value={pct(summary.metrics.mdd.value)} detail="Close-to-close fixture NAV"/><Metric label="Sharpe ratio" value="UNAVAILABLE" detail="No observed risk-free series"/></QXMetricRow><ResearchSeries series={[fixtureReturns.reduce<number[]>((a,r)=>[...a,a.at(-1)!*(1+r.value-fee/10000)],[100])]} label="DEMO NAV · starts at 100 · synthetic session index"/><ScopeNote/></QXPanel>;

  let content:React.ReactNode;
  if(view==='overview'||view==='markets') content=<>
    <QXMetricRow>{securities.slice(0,4).map(s=>{const b=demoSnapshot(s.symbol).bars;return <Metric key={s.symbol} label={`${s.symbol} · DEMO`} value={money(b.at(-1)!.close)} detail={`${pct(b.at(-1)!.close/b.at(-2)!.close-1)} synthetic session`}/>;})}</QXMetricRow>
    <div className="workspace-grid"><div>{chartPanel}</div><div className="stack">{dataPanel}<QXPanel><Heading title="Research context" detail="Illustrative scores · no model inference"/><QXScoreBars items={[["Trend",68,'DEMO'],['Liquidity',81,'DEMO'],['Value',null,'No financial statements']]}/><p className="qx-note">Scores are layout fixtures. Missing values stay unavailable.</p></QXPanel></div></div>
    <QXPanel><Heading title="Watchlist" detail="Select an instrument to retain context across workspaces"/>{watchlist}{filtered.length===0&&<p className="empty">No fixture instruments match “{query}”.</p>}</QXPanel>
  </>;
  else if(view==='research') content=<><div className="workspace-grid"><div>{chartPanel}</div><div className="stack"><QXPanel><Heading title={`${symbol} · Research`} detail={securities.find(s=>s.symbol===symbol)?.name??'Fixture instrument'}/><QXScoreBars items={[["Quality",74,'Synthetic'],['Momentum',62,'Synthetic'],['Value',null,'DCF unavailable'],['Evidence coverage',null,'No SEC integration']]}/><ScopeNote/></QXPanel>{dataPanel}</div></div><QXPanel><Heading title="Evidence & valuation" detail="Backend-dependent research is not simulated"/><p className="empty">UNAVAILABLE · Financial statements, fair value, price targets, forecast probabilities and point-in-time evidence require production data and research engines.</p></QXPanel></>;
  else if(view==='portfolio'||view==='paper') content=<>
    <QXPanel><Heading title={view==='paper'?'Paper account · display fixture':'Portfolio · display fixture'} detail="Read-only synthetic holdings · no orders or account connection"/><QXMetricRow><Metric label="Fixture equity" value={money(positions.reduce((s,p)=>s+p.shares*demoSnapshot(p.symbol).bars.at(-1)!.close,10000))} detail="Includes $10,000 synthetic cash"/><Metric label="Account status" value="DEMO" detail="No production account loaded"/><Metric label="Execution authority" value="NONE" detail="No trade or paper order functions"/></QXMetricRow><QXTable aria-label="Synthetic demo positions"><thead><tr><th>Instrument</th><th>Fixture units</th><th>Fixture cost</th><th>Fixture value</th><th>Authority</th></tr></thead><tbody>{positions.map(p=><tr key={p.symbol}><td>{p.symbol}<small className="cell-sub">DEMO position</small></td><td>{p.shares}</td><td>{money(p.cost)}</td><td>{money(p.shares*demoSnapshot(p.symbol).bars.at(-1)!.close)}</td><td>NONE</td></tr>)}</tbody></QXTable><ScopeNote/></QXPanel>{analytics}</>;
  else if(view==='lab') content=<><QXPanel><Heading title="Research Lab · local fee illustration" detail="Deterministic fixture arithmetic; not a backtest or validated strategy"/><label className="fee-label">Illustrative daily fee deduction <b>{fee} bps / session</b><input type="range" min="0" max="10" step="1" value={fee} onChange={e=>setFee(Number(e.target.value))}/></label><p className="qx-note">Deducted from every synthetic daily return. No turnover, trades, slippage, fills, holidays, OOS validation or prospective performance evidence.</p></QXPanel>{analytics}<QXPanel><Heading title="External research engines" detail="Not packaged in this frontend"/><p className="empty">UNAVAILABLE · GS Quant, Qlib, Riskfolio, model training, automated hypotheses and commodity pipelines require the original backend.</p></QXPanel></>;
  else if(view==='derivatives') content=<><QXPanel><Heading title="Volatility surface · conceptual fixture" detail="Generated design sample · not an observed option chain"/><div className="heatmap"><span>Expiry / strike</span>{['90%','95%','ATM','105%','110%'].map(x=><b key={x}>{x}</b>)}{[7,30,60,90].map((day,i)=><div className="heatmap-row" key={day}><b>{day}d</b>{[0,1,2,3,4].map(j=><span key={j} style={{background:`color-mix(in srgb, var(--qx-chart-blue) ${15+Math.abs(j-2)*13+i*4}%, var(--qx-surface))`}}>{(22+Math.abs(j-2)*1.8+i*.6).toFixed(1)}%</span>)}</div>)}</div><ScopeNote/></QXPanel><QXPanel><Heading title="Options analytics" detail="UNAVAILABLE"/><p className="empty">Live chains, Greeks, GEX, volatility calibration, futures and 3D production visualization are not connected.</p></QXPanel></>;
  else if(view==='macro') content=<><QXPanel><Heading title="Macro regime · design fixture" detail="Synthetic scores, not current economic observations"/><QXScoreBars items={[["Growth",56,'DEMO'],['Liquidity',64,'DEMO'],['Inflation pressure',42,'DEMO'],['Observed regime probability',null,'UNAVAILABLE']]}/><ScopeNote/></QXPanel><QXPanel><Heading title="Macro data" detail="UNAVAILABLE"/><p className="empty">FRED, release vintages, yield curves, historical regimes and cross-asset pipelines require optional data integrations.</p></QXPanel></>;
  else if(view==='news'||view==='earnings') content=<QXPanel><Heading title="News & earnings" detail="Editorial placeholders · no live feed"/><QXSegmentedControl label="News section" value={newsTab} onChange={setNewsTab} items={[{value:'briefs',label:'Briefs'},{value:'earnings',label:'Earnings'}]}/><div className="editorial-list">{(newsTab==='briefs'?['Company filing review','Macro release context','Portfolio thesis review']:['Earnings calendar','Reported versus expected','Post-event evidence']).map((title,i)=><article key={title}><span className="story-number">0{i+1}</span><div><QXBadge>DEMO PLACEHOLDER</QXBadge><h3>{title}</h3><p>{newsTab==='briefs'?'Connect a public source adapter to develop this research workflow. No article or event is represented as real.':'UNAVAILABLE · No actual dates, results, consensus estimates or surprises are supplied.'}</p></div></article>)}</div><ScopeNote/></QXPanel>;
  else if(view==='intelligence') content=<QXPanel><Heading title="Intelligence · research workspace" detail="Provider and retrieval services disconnected"/><div className="empty"><h3>Evidence is unavailable in this preview</h3><p>Ask AI, model-generated claims, archived research, source retrieval and autonomous agents need authenticated backend services. This preview does not call any AI provider.</p><QXButton onClick={()=>navigate('research')}>Open fixture research ↗</QXButton></div></QXPanel>;
  else content=<><QXPanel><Heading title="Runtime & provenance" detail="Isolated frontend · upstream 1a915935609c"/><div className="runtime-grid"><div><span>Runtime</span><b>React + TypeScript + Vite</b></div><div><span>Default data</span><b>Synthetic fixtures only</b></div><div><span>Persistence</span><b>Local theme preference only</b></div><div><span>Execution authority</span><b>NONE</b></div></div></QXPanel><QXPanel><Heading title="Optional public market adapter" detail="Explicit connection · unauthenticated HTTPS GET only"/><p>The endpoint must supply the selected instrument ({symbol}) using the schema in README.md. All other panels remain DEMO. No cookies, keys, authorization headers or redirects are sent.</p><div className="adapter-actions"><QXButton onClick={connect} disabled={connecting}>{connecting?'Connecting…':'Connect public snapshot'}</QXButton><QXButton onClick={()=>{setExternal(null);setAdapterState('Disconnected. Explicit DEMO fixtures active.');}}>Use demo data</QXButton></div><p className="qx-note">{publicUrl?'Public endpoint configured. No automatic request is made.':'No endpoint configured. Preview works fully offline after installation.'}</p><p role="status">{adapterState}</p></QXPanel><QXPanel><Heading title="Unavailable production functions" detail="No production installation, data or service dependencies"/><dl className="capabilities">{unavailable.map(([title,detail])=><div key={title}><dt>{title}</dt><dd>{detail}</dd></div>)}</dl></QXPanel></>;

  return <div className="app-shell"><a className="skip-link" href="#workspace">Skip to workspace</a>
    {menu&&<button className="nav-scrim" aria-label="Close navigation" onClick={()=>{setMenu(false);menuButton.current?.focus();}}/>}
    <aside id="workspace-nav" className={`sidebar ${menu?'is-open':''}`} inert={mobile&&!menu?true:undefined}>
      <a className="brand" href="?view=overview" onClick={e=>{e.preventDefault();navigate('overview');}}><span className="brand-mark" aria-hidden="true">N</span><span>NORVYQ<small>QUANT INTELLIGENCE</small></span></a>
      <div className="preview-label">FRONTEND PREVIEW <span>01</span></div>
      <nav aria-label="Workspace navigation">{(['decision','analysis','research'] as const).map(group=><div className="nav-group" key={group}><p>{NAV_GROUP_LABELS.en[group]}</p>{nav.filter(n=>n.group===group).map((n,i)=><button ref={group==='decision'&&i===0?firstNav:undefined} key={n.id} aria-current={view===n.id?'page':undefined} onClick={()=>navigate(n.id)}><span className="nav-glyph" aria-hidden="true">{n.glyph}</span><span>{n.label}</span>{view===n.id&&<i/>}</button>)}</div>)}</nav>
      <div className="sidebar-foot"><div><i className="status-dot demo"/> Demo workspace</div><small>Execution authority · NONE</small><label>Appearance<QXSelect aria-label="Appearance" value={theme} onChange={e=>setTheme(e.target.value)}><option value="dark">Dark</option><option value="light">Light</option><option value="system">System</option></QXSelect></label></div>
    </aside>
    <div className="shell-content"><header className="topbar"><div className="topbar-left"><QXButton ref={menuButton} className="menu-button" aria-label="Toggle navigation" aria-expanded={menu} aria-controls="workspace-nav" onClick={()=>setMenu(!menu)}>☰</QXButton><span className="breadcrumb">Workspace <span>/</span> <b>{current.label}</b></span></div><div className="search-wrap"><QXInput ref={search} aria-label="Search fixture instruments" placeholder="Search fixture instruments…" value={query} onChange={e=>setQuery(e.target.value)} onKeyDown={e=>{if(e.key==='Enter'&&filtered[0])navigate('research',filtered[0].symbol);}}/><kbd>Ctrl K</kbd>{query&&<div className="search-results" role="region" aria-label="Fixture search results">{filtered.length?filtered.map(s=><button key={s.symbol} onClick={()=>navigate('research',s.symbol)}><b>{s.symbol}</b><span>{s.name}</span><QXBadge>DEMO</QXBadge></button>):<p>No fixture instruments found.</p>}</div>}</div><span className="header-status"><i className="status-dot demo"/>DEMO DATA</span></header>
      <div className="demo-banner"><span><b>Development preview</b> · Synthetic data only, except an explicitly connected public chart.</span><span>No trading · No production access</span></div>
      <main id="workspace" tabIndex={-1}><div className="page-heading"><div><span className="eyebrow">NORVYQ / {current.glyph}</span><h1>{current.label}</h1><p>{view==='overview'?'Market context, research, and portfolio oversight.':current.sub} <span className="fixture-date">Fixture session · 2025</span></p></div><div className="page-actions"><QXSelect aria-label="Selected instrument" value={symbol} onChange={e=>navigate(view,e.target.value)}>{securities.map(s=><option key={s.symbol}>{s.symbol}</option>)}</QXSelect><QXButton onClick={exportFixture}>Export demo JSON ↓</QXButton></div></div><div className="workspace-content">{content}</div><footer className="workspace-footer"><span>NORVYQ · Isolated development package</span><span>DEMO / READ ONLY · Authority NONE</span></footer></main>
    </div></div>;
}
