/** Daily, decimal, time-weighted analytics. No ordering/sizing authority. */
export const ANALYTICS_VERSION = 'QX_PERFORMANCE_2026.10.18.1';
export type DailyReturn = { date: string; value: number; startDate?: string; regime?: string };
export type RateInput = { annual: number | null; source: string; kind: 'ASSUMED' | 'OBSERVED_PERIOD_MATCHED'; asOf?: string | null; periodStart?:string; periodEnd?:string };
export type AnalyticsContext = {
  scope: string; returnBasis: string; costs: string; cashFlows: 'NONE' | 'ADJUSTED_TWR' | 'UNKNOWN';
  benchmark: string; riskFree: RateInput; marAnnual?: number; periodsPerYear?: number;
  warnings?: string[];
};
export type AnalyticsInput = { returns: DailyReturn[]; benchmark?: DailyReturn[]; context: AnalyticsContext; trades?: ClosedTrade[] };
export type Metric = { value: number | null; reason: string | null };
export type MetricKey = 'totalReturn' | 'cagr' | 'mdd' | 'volatility' | 'sharpe' | 'sortino' | 'ulcer' | 'upi' | 'calmar' | 'downside';
export type DrawdownEpisode = { peakDate: string | null; recoveryDate: string | null; sessions: number; calendarDays: number | null; ongoing: boolean };
export type AnalyticsSummary = {
  observations: number; start: string | null; end: string | null; years: number;
  metrics: Record<MetricKey, Metric>;
  duration: { current: DrawdownEpisode; maximum: DrawdownEpisode; completedMaximumSessions:number; lastPeak: string | null; lastRecovery: string | null };
};
export type RollingPoint = { date: string; window: number; beta: Metric; volatility: Metric; sharpe: Metric; sortino: Metric; calmar:Metric };
export type ClosedTrade = { id: string; netPnl: number; costsIncluded: boolean };
export type AnalyticsReport = {
  version: string; context: AnalyticsContext; summary: AnalyticsSummary; rolling: RollingPoint[];
  beta: Record<number, Metric>; benchmarkObservations: number;
  kelly: { full: Metric; winRate: number | null; payoff: number | null; samples: number; authority: 'REFERENCE_ONLY' };
  risk: { authority: 'OBSERVATION_ONLY'; signals: Array<{ code: string; detail: string }>; regimes: Array<{ regime: string; observations: number; metrics: AnalyticsSummary['metrics'] }> };
  warnings: string[];
};
export const METRIC_KEYS: MetricKey[] = ['totalReturn','cagr','mdd','volatility','sharpe','sortino','ulcer','upi','calmar','downside'];
const EPS = 1e-12;
const missing = (reason: string): Metric => ({ value: null, reason });
const metric = (value: number, reason = 'NON_FINITE_RESULT'): Metric => Number.isFinite(value) ? { value, reason: null } : missing(reason);
const ratio = (numerator: number | null, denominator: number | null, reason: string): Metric => numerator == null ? missing('NUMERATOR_UNAVAILABLE') : denominator == null || denominator <= EPS ? missing(reason) : metric(numerator / denominator);
const mean = (x: number[]) => x.reduce((s,v) => s+v,0)/x.length;
// Sample SD (n-1); LPM2 below deliberately divides by ALL n observations.
export function dailyMoments(values: number[], marAnnual = 0, periods = 252) {
  const target = Math.expm1(Math.log1p(marAnnual)/periods), average = mean(values);
  let m = 0, sum = 0, n = 0, down = 0;
  for (const value of values) { n++; const delta=value-m; m+=delta/n; sum+=delta*(value-m); down+=Math.min(0,value-target)**2; }
  return { mean: average, target, sd: values.length>1?Math.sqrt(Math.max(0,sum/(values.length-1))):0, downside: Math.sqrt(down/values.length) };
}
const validDate = (s: string) => /^\d{4}-\d{2}-\d{2}$/.test(s) && Number.isFinite(Date.parse(s)) && new Date(s).toISOString().slice(0,10)===s;
export function validateDailyReturns(rows: DailyReturn[]): string | null {
  for (let i=0;i<rows.length;i++) {
    const r=rows[i];
    if(!validDate(r.date)||!Number.isFinite(r.value)||r.value<=-1) return 'INVALID_DATE_RETURN_OR_NONPOSITIVE_EQUITY';
    if(i&&r.date<=rows[i-1].date) return 'DUPLICATE_OR_UNORDERED_DATE';
    if(r.startDate&&(!validDate(r.startDate)||r.startDate>=r.date||i>0&&r.startDate!==rows[i-1].date)) return 'RETURN_INTERVAL_GAP';
  }
  return null;
}
function emptySummary(rows: DailyReturn[], reason: string): AnalyticsSummary {
  const episode: DrawdownEpisode={peakDate:null,recoveryDate:null,sessions:0,calendarDays:null,ongoing:false};
  return { observations: rows.length, start:rows[0]?.startDate??rows[0]?.date??null,end:rows.at(-1)?.date??null,years:0,
    metrics:Object.fromEntries(METRIC_KEYS.map(k=>[k,missing(reason)])) as AnalyticsSummary['metrics'],
    duration:{current:episode,maximum:episode,completedMaximumSessions:0,lastPeak:null,lastRecovery:null} };
}
export function summarizeDaily(rows: DailyReturn[], context: AnalyticsContext): AnalyticsSummary {
  const invalid=validateDailyReturns(rows), periods=context.periodsPerYear??252, mar=context.marAnnual??0;
  if(invalid||!rows.length||context.cashFlows==='UNKNOWN'||!Number.isFinite(periods)||periods<=0||!Number.isFinite(mar)||mar<=-1)
    return emptySummary(rows,invalid??(!rows.length?'INSUFFICIENT_OBSERVATIONS':context.cashFlows==='UNKNOWN'?'CASH_FLOW_ADJUSTMENT_UNAVAILABLE':'INVALID_ANNUALIZATION_OR_MAR'));
  const values=rows.map(r=>r.value), moments=dailyMoments(values,mar,periods), start=rows[0].startDate??null;
  let logNav=0, logPeak=0, mdd=0, sumDD=0, peakDate=start, peakIndex=-1, lastRecovery:string|null=null,completedMaximumSessions=0;
  let maximum: DrawdownEpisode={peakDate:null,recoveryDate:null,sessions:0,calendarDays:null,ongoing:false};
  let current: DrawdownEpisode={...maximum};
  for(let i=0;i<rows.length;i++) {
    const wasUnder=logNav<logPeak-EPS;
    logNav+=Math.log1p(values[i]);
    const dd=Math.expm1(Math.min(0,logNav-logPeak));
    mdd=Math.min(mdd,dd); sumDD+=dd*dd;
    if(logNav>=logPeak-EPS) {
      if(wasUnder) {
        lastRecovery=rows[i].date;
        const completed={...current,sessions:i-peakIndex,recoveryDate:rows[i].date,ongoing:false,calendarDays:peakDate?Math.round((Date.parse(rows[i].date)-Date.parse(peakDate))/86400000):null};
        completedMaximumSessions=Math.max(completedMaximumSessions,completed.sessions);
        if(completed.sessions>=maximum.sessions) maximum=completed;
      }
      logPeak=Math.max(logPeak,logNav); peakDate=rows[i].date; peakIndex=i;
      current={peakDate,recoveryDate:null,sessions:0,calendarDays:0,ongoing:false};
    } else {
      current={peakDate,recoveryDate:null,sessions:i-peakIndex,calendarDays:peakDate?Math.round((Date.parse(rows[i].date)-Date.parse(peakDate))/86400000):null,ongoing:true};
      if(current.sessions>=maximum.sessions) maximum={...current};
    }
  }
  const years=rows.length/periods, ulcer=Math.sqrt(sumDD/rows.length), vol=moments.sd*Math.sqrt(periods), downside=moments.downside*Math.sqrt(periods);
  const cagr=rows.length>=2?metric(Math.expm1(logNav/years)):missing('CAGR_REQUIRES_TWO_RETURN_OBSERVATIONS');
  const rf=context.riskFree.annual, rfValid=rf!=null&&Number.isFinite(rf)&&rf>-1&&(context.riskFree.kind==='ASSUMED'||context.riskFree.periodStart===(start??rows[0].date)&&context.riskFree.periodEnd===rows.at(-1)!.date);
  const rfDaily=rfValid?Math.expm1(Math.log1p(rf)/periods):null;
  const sample=rows.length>=20;
  const metrics: AnalyticsSummary['metrics']={
    totalReturn:metric(Math.expm1(logNav)),cagr,mdd:metric(mdd),ulcer:metric(ulcer*100),
    volatility:rows.length>=2?metric(vol):missing('INSUFFICIENT_OBSERVATIONS'),downside:metric(downside),
    sharpe:!sample?missing('MINIMUM_20_DAILY_RETURNS'):rfDaily==null?missing('RISK_FREE_RATE_UNAVAILABLE'):ratio((moments.mean-rfDaily)*periods,vol,'ZERO_VOLATILITY'),
    sortino:!sample?missing('MINIMUM_20_DAILY_RETURNS'):ratio((moments.mean-moments.target)*periods,downside,'ZERO_DOWNSIDE_DEVIATION'),
    upi:!sample?missing('MINIMUM_20_DAILY_RETURNS'):!rfValid?missing('RISK_FREE_RATE_UNAVAILABLE'):ratio(cagr.value==null?null:cagr.value-rf,ulcer,'ZERO_ULCER_INDEX'),
    calmar:!sample?missing('MINIMUM_20_DAILY_RETURNS'):ratio(cagr.value,Math.abs(mdd),'ZERO_DRAWDOWN'),
  };
  return { observations:rows.length,start:start??rows[0].date,end:rows.at(-1)!.date,years,metrics,duration:{current,maximum,completedMaximumSessions,lastPeak:peakDate,lastRecovery} };
}
export function estimateKelly(trades: ClosedTrade[] = []): AnalyticsReport['kelly'] {
  const base={winRate:null,payoff:null,samples:trades.length,authority:'REFERENCE_ONLY' as const};
  if(trades.length<30)return {...base,full:missing('MINIMUM_30_COST_NET_CLOSED_TRADES')};
  if(new Set(trades.map(t=>t.id)).size!==trades.length||trades.some(t=>!Number.isFinite(t.netPnl)||!t.costsIncluded))return {...base,full:missing('INVALID_DUPLICATE_OR_GROSS_TRADE')};
  const wins=trades.filter(t=>t.netPnl>0), losses=trades.filter(t=>t.netPnl<0);
  if(!wins.length||!losses.length)return {...base,full:missing('BOTH_WINS_AND_LOSSES_REQUIRED')};
  // Breakeven trades count in n; use the actual loss probability, not 1-p(win).
  const p=wins.length/trades.length,q=losses.length/trades.length,b=mean(wins.map(t=>t.netPnl))/-mean(losses.map(t=>t.netPnl));
  return {...base,full:metric(p-q/b),winRate:p,payoff:b};
}
export function analyzePerformance(input: AnalyticsInput, includeRolling=true): AnalyticsReport {
  const {returns:rows,context}=input, summary=summarizeDaily(rows,context), valid=summary.metrics.totalReturn.value!=null;
  const warnings=[...(context.warnings??[])];
  if(context.riskFree.kind==='ASSUMED')warnings.push('RISK_FREE_IS_A_FIXED_SCENARIO_ASSUMPTION_NOT_HISTORICAL_OBSERVATIONS');
  if(summary.years<1)warnings.push('ANNUALIZED_FROM_LESS_THAN_ONE_YEAR_DESCRIPTIVE_ONLY');
  const bmRows=input.benchmark??[], bmInvalid=validateDailyReturns(bmRows);
  const benchmark=new Map(bmInvalid?[]:bmRows.map(r=>[r.date,r]));
  const aligned=rows.map(r=>{const b=benchmark.get(r.date);return b&&r.startDate===b.startDate?b:null;});
  const count=aligned.filter(Boolean).length;
  if(count<rows.length)warnings.push(bmInvalid??'BENCHMARK_MISSING_OR_RETURN_INTERVALS_MISMATCHED_NO_FILL');
  const beta:Record<number,Metric>={},rolling:RollingPoint[]=[];
  for(const window of [20,60,120]) {
    beta[window]=missing('INSUFFICIENT_COMMON_DAILY_RETURNS');
    if(!valid)continue;
    for(let i=window-1;i<rows.length;i++) {
      const from=i-window+1, a=rows.slice(from,i+1), b=aligned.slice(from,i+1);
      let bMetric=missing('INSUFFICIENT_COMMON_DAILY_RETURNS');
      if(b.every(x=>x!=null)) {
        const x=a.map(r=>r.value), y=b.map(r=>r!.value), xm=mean(x),ym=mean(y);
        let cov=0,variance=0;for(let j=0;j<window;j++){cov+=(x[j]-xm)*(y[j]-ym);variance+=(y[j]-ym)**2;}
        bMetric=variance>EPS?metric(cov/variance):missing('ZERO_BENCHMARK_VARIANCE');
      }
      if(i===rows.length-1)beta[window]=bMetric;
      if(includeRolling){
        const p=context.periodsPerYear??252,m=dailyMoments(a.map(r=>r.value),context.marAnnual??0,p),vol=m.sd*Math.sqrt(p),down=m.downside*Math.sqrt(p),rf=context.riskFree.annual;
        const rfValid=context.riskFree.kind==='ASSUMED'&&rf!=null&&Number.isFinite(rf)&&rf>-1;
        rolling.push({date:rows[i].date,window,beta:bMetric,volatility:metric(vol),sharpe:rfValid?ratio((m.mean-Math.expm1(Math.log1p(rf)/p))*p,vol,'ZERO_VOLATILITY'):missing('PERIOD_MATCHED_RISK_FREE_RATE_REQUIRED'),sortino:ratio((m.mean-m.target)*p,down,'ZERO_DOWNSIDE_DEVIATION'),calmar:summarizeDaily(a,context).metrics.calmar});
      }
    }
  }
  const signals:AnalyticsReport['risk']['signals']=[];
  if(valid&&rows.length>=40) {
    const previous=summarizeDaily(rows.slice(-40,-20),context),recent=summarizeDaily(rows.slice(-20),context);
    const oldUI=previous.metrics.ulcer.value!,newUI=recent.metrics.ulcer.value!;
    if(newUI>oldUI+EPS)signals.push({code:'ULCER_RISING',detail:`20-session Ulcer ${oldUI.toFixed(3)} → ${newUI.toFixed(3)} percentage points; descriptive comparison.`});
    if(recent.metrics.totalReturn.value!>previous.metrics.totalReturn.value!&&newUI>oldUI+EPS)signals.push({code:'RETURN_UP_RISK_WORSE',detail:'Recent 20-session return improved while drawdown severity increased.'});
    const beta20=rolling.filter(p=>p.window===20&&p.beta.value!=null), last=beta20.at(-1),before=beta20.at(-21);
    if(last&&before&&Math.abs(last.beta.value!-before.beta.value!)>=.5)signals.push({code:'BETA_SHIFT_REVIEW',detail:`20-session beta changed by ${(last.beta.value!-before.beta.value!).toFixed(2)}; 0.50 is an unvalidated observation threshold.`});
  }
  if(summary.duration.current.ongoing)signals.push({code:'DRAWDOWN_ONGOING',detail:`Unrecovered for ${summary.duration.current.sessions} observed sessions; historical maximum ${summary.duration.maximum.sessions}. No automatic action.`});
  if(summary.duration.completedMaximumSessions>0&&summary.duration.current.sessions>summary.duration.completedMaximumSessions)signals.push({code:'RECOVERY_LONGER_THAN_PAST_EPISODES',detail:`Current ${summary.duration.current.sessions} sessions exceeds the longest completed recovery (${summary.duration.completedMaximumSessions}); historical comparison, not a liquidation threshold.`});
  const regimes:AnalyticsReport['risk']['regimes']=[];
  for(const regime of [...new Set(rows.map(r=>r.regime).filter((r):r is string=>!!r))]) {
    const subset=rows.filter(r=>r.regime===regime).map(r=>({date:r.date,value:r.value}));
    const metrics=summarizeDaily(subset,context).metrics;
    // Disjoint regime days are not a continuous investable path.
    for(const key of ['cagr','mdd','ulcer','upi','calmar'] as const)metrics[key]=missing('DISJOINT_REGIME_SLICE_NOT_CONTINUOUS_EQUITY');
    regimes.push({regime,observations:subset.length,metrics});
  }
  return {version:ANALYTICS_VERSION,context,summary,rolling,beta,benchmarkObservations:count,kelly:estimateKelly(input.trades),risk:{authority:'OBSERVATION_ONLY',signals,regimes},warnings};
}
export type AnalyticsRange='1M'|'3M'|'6M'|'1Y'|'ALL';
export function selectAnalyticsRange(input: AnalyticsInput, range: AnalyticsRange): AnalyticsInput {
  if(range==='ALL'||!input.returns.length)return input;
  const end=new Date(input.returns.at(-1)!.date),months={'1M':1,'3M':3,'6M':6,'1Y':12}[range];
  const day=end.getUTCDate();end.setUTCDate(1);end.setUTCMonth(end.getUTCMonth()-months);const lastDay=new Date(Date.UTC(end.getUTCFullYear(),end.getUTCMonth()+1,0)).getUTCDate();end.setUTCDate(Math.min(day,lastDay));
  const cutoff=end.toISOString().slice(0,10);
  return {...input,returns:input.returns.filter(r=>r.date>cutoff),benchmark:input.benchmark?.filter(r=>r.date>cutoff),trades:undefined};
}
/** Component-owned bounded selector; caches derived values without mutating React inputs. */
export function createPerformanceSelector(input:AnalyticsInput) {
  const cache=new Map<string,AnalyticsReport>();
  return (range:AnalyticsRange,marAnnual:number)=>{
    const key=`${range}:${marAnnual}`,prior=cache.get(key);if(prior)return prior;
    const next=analyzePerformance(selectAnalyticsRange({...input,context:{...input.context,marAnnual}},range));
    if(cache.size>=20)cache.clear();cache.set(key,next);return next;
  };
}
export function comparePerformance(champion: AnalyticsInput, challenger: AnalyticsInput) {
  const comparable=champion.returns.length>0&&!validateDailyReturns(champion.returns)&&!validateDailyReturns(challenger.returns)&&champion.context.cashFlows!=='UNKNOWN'&&challenger.context.cashFlows!=='UNKNOWN'&&champion.returns.length===challenger.returns.length&&champion.returns.every((r,i)=>r.date===challenger.returns[i].date&&r.startDate===challenger.returns[i].startDate)
    && JSON.stringify(champion.context)===JSON.stringify(challenger.context)
    && champion.benchmark?.length===champion.returns.length&&!validateDailyReturns(champion.benchmark)
    && JSON.stringify(champion.benchmark??[])===JSON.stringify(challenger.benchmark??[]);
  const a=summarizeDaily(champion.returns,champion.context),b=summarizeDaily(challenger.returns,challenger.context);
  return {status:comparable?'COMPARABLE' as const:'NOT_COMPARABLE' as const,reason:comparable?null:'PERIOD_BENCHMARK_COST_RATE_OR_CASH_FLOW_PARITY_NOT_VERIFIED',authority:'REFERENCE_ONLY',ranking:'EXISTING_PROFIT_FACTOR_AND_MDD_POLICY_UNCHANGED',
    differences:METRIC_KEYS.map(key=>{const x=a.metrics[key].value,y=b.metrics[key].value,delta=comparable&&x!=null&&y!=null?y-x:null;
      const direction=delta==null?'UNAVAILABLE':Math.abs(delta)<EPS?'UNCHANGED':(['ulcer','volatility','downside'].includes(key)?delta<0:delta>0)?'IMPROVED':'WORSENED';
      return {metric:key,champion:x,challenger:y,delta,direction};}),
    durationDelta:comparable?b.duration.maximum.sessions-a.duration.maximum.sessions:null};
}
