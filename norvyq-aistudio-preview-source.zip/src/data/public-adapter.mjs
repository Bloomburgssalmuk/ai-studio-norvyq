/** Optional, unauthenticated GET adapter. This module has no trading methods. */
export function validateSnapshot(input, symbol) {
  if (!input || input.symbol !== symbol || input.currency !== 'USD' ||
      typeof input.source !== 'string' || !input.source.trim() || input.source.length > 120 ||
      typeof input.asOf !== 'string' || !Number.isFinite(Date.parse(input.asOf)) ||
      !Array.isArray(input.bars) || input.bars.length < 2 || input.bars.length > 500) {
    throw new Error('Invalid public snapshot metadata or bar count.');
  }
  let previous = '';
  const bars = input.bars.map(row => {
    if (!row || typeof row.date !== 'string' || !/^\d{4}-\d{2}-\d{2}$/.test(row.date) ||
        !Number.isFinite(Date.parse(row.date)) || new Date(row.date).toISOString().slice(0,10) !== row.date ||
        row.date <= previous || Date.parse(row.date) > Date.parse(input.asOf) ||
        !['open','high','low','close'].every(k => typeof row[k] === 'number' && Number.isFinite(row[k]) && row[k] > 0) ||
        row.low > Math.min(row.open,row.close) || row.high < Math.max(row.open,row.close) || row.low > row.high) {
      throw new Error('Invalid, unordered, or future OHLC bars.');
    }
    previous = row.date;
    return { date: row.date, open: row.open, high: row.high, low: row.low, close: row.close };
  });
  return { symbol, currency: 'USD', source: input.source.trim(), asOf: input.asOf, bars, mode: 'READ_ONLY' };
}

export function publicEndpoint(value) {
  const url = new URL(value);
  // Public data only: no query tokens, userinfo, fragments, or local network hosts.
  if (url.protocol !== 'https:' || url.username || url.password || url.search || url.hash ||
      !url.hostname.includes('.') || /^[\d.]+$/.test(url.hostname) ||
      /(?:^|\.)(?:localhost|local|internal|test|invalid)$/.test(url.hostname) || url.hostname.includes(':')) {
    throw new Error('Use a public HTTPS URL without credentials, query parameters, or fragments.');
  }
  return url;
}

export async function loadPublicSnapshot(endpoint, symbol, fetcher = fetch) {
  const url = publicEndpoint(endpoint);
  const response = await fetcher(url.href, {
    method: 'GET', credentials: 'omit', redirect: 'error',
    referrerPolicy: 'no-referrer', headers: { Accept: 'application/json' },
    signal: AbortSignal.timeout(8000),
  });
  if (!response.ok) throw new Error(`Public adapter returned HTTP ${response.status}.`);
  return validateSnapshot(await response.json(), symbol);
}
