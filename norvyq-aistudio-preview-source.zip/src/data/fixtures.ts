export type Bar = { date: string; open: number; high: number; low: number; close: number };
export type Snapshot = { symbol: string; currency: string; source: string; asOf: string; bars: Bar[]; mode: 'DEMO' | 'READ_ONLY' };
export const securities = [
  {symbol:'QQQ',name:'Nasdaq 100 ETF',base:510,sector:'Index'},
  {symbol:'SPY',name:'S&P 500 ETF',base:580,sector:'Index'},
  {symbol:'NVDA',name:'NVIDIA',base:135,sector:'Technology'},
  {symbol:'MSFT',name:'Microsoft',base:420,sector:'Technology'},
  {symbol:'AAPL',name:'Apple',base:230,sector:'Technology'},
  {symbol:'TLT',name:'20+ Year Treasury ETF',base:91,sector:'Rates'},
];
export const FIXTURE_NOTICE = 'Synthetic fixtures · not market observations, forecasts, or investment advice.';
export function demoSnapshot(symbol: string): Snapshot {
  const base=securities.find(s=>s.symbol===symbol)?.base ?? 100;
  let close=base;
  const bars: Bar[]=[];
  for(let day=0;bars.length<90;day++) {
    const d=new Date(Date.UTC(2025,0,2+day));
    if([0,6].includes(d.getUTCDay())) continue;
    const i=bars.length, open=close;
    close=open*(1+0.001+Math.sin(i*1.73)*0.007+Math.cos(i*0.29)*0.004);
    bars.push({date:d.toISOString().slice(0,10),open,close,high:Math.max(open,close)*1.003,low:Math.min(open,close)*0.997});
  }
  return {symbol,currency:'USD',source:'Deterministic NORVYQ preview fixture; weekday calendar, holidays not modeled',asOf:bars.at(-1)!.date+'T20:00:00Z',bars,mode:'DEMO'};
}
const qqqBars=demoSnapshot('QQQ').bars;
export const fixtureReturns=qqqBars.slice(1).map((b,i)=>({date:b.date,startDate:qqqBars[i].date,value:b.close/qqqBars[i].close-1}));
export const positions=[{symbol:'QQQ',shares:35,cost:510},{symbol:'MSFT',shares:18,cost:420},{symbol:'TLT',shares:100,cost:91}];
